package com.iot.waterTank;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WaterTankApplicationTests {

	@Test
	void contextLoads() {
	}

}
