package com.iot.waterTank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WaterTankApplication {

	public static void main(String[] args) {
		SpringApplication.run(WaterTankApplication.class, args);
	}

}
